﻿namespace FileExplorer
{
    public class FileItem
    {
        public string Name { get; set; }
    }
}